import DemoInterface from "@/components/chat/DemoInterface";

export const metadata = {
  title: "Demo | VitalDocs AI",
  description: "Try VitalDocs AI — no sign-in required.",
};

export default function DemoPage() {
  return <DemoInterface />;
}
